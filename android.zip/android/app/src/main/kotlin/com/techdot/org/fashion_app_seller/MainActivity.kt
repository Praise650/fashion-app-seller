package com.techdot.org.fashion_app_seller

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
